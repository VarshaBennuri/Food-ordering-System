package home;

class Main
{
	public static void main(String args[])
	{
		Homepage x = new Homepage();
	}
}